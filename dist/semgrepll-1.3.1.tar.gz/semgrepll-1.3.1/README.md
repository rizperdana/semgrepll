# semgrepll - Local Semantic Code Search

<p align="center">
  <img src="semgrepll-demo.jpg" alt="semgrepll demo" width="800">
</p>

<p align="center">
  <a href="https://pypi.org/project/semgrepll/">
    <img src="https://img.shields.io/pypi/v/semgrepll?color=10b981" alt="PyPI">
  </a>
  <a href="https://github.com/rizperdana/semgrepll/blob/master/LICENSE">
    <img src="https://img.shields.io/pypi/l/semgrepll?color=10b981" alt="License: MIT">
  </a>
  <a href="https://github.com/rizperdana/semgrepll">
    <img src="https://img.shields.io/github/stars/rizperdana/semgrepll?color=10b981" alt="GitHub stars">
  </a>
</p>

Local semantic grep using embeddings - **100% offline capable**.

## Features

- **Multi-backend support**: llama.cpp, ONNX, Ollama
- **Auto-detection**: Automatically picks fastest available local backend
- **Hybrid storage**: SQLite (small projects) or LanceDB (large)
- **100% offline**: No external connections
- **Embedding caching**: Fast re-indexing
- **Semantic search**: Find code by meaning, not just keywords

## Backends (priority order)

| Rank | Backend | Speed | Notes |
|------|---------|-------|-------|
| 1 | llama.cpp | ~1s | Fastest - requires GGUF model |
| 2 | ONNX | ~3s | Local - uses HF model files |
| 3 | Ollama | ~6s | Local server fallback |

## Installation

```bash
pip install semgrepll

# Optional: ONNX backend support
pip install semgrepll[onnx]
```

## Usage

```bash
# Index a project (auto-detects backend)
semgrep index /path/to/project

# Search semantically
semgrep search "authentication logic"

# List indexed projects
semgrep ls
```

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `EMBED_BACKEND` | Backend: auto, llama, onnx, ollama | auto |
| `EMBED_MODEL` | Model name | mxbai-embed-large-v1 |
| `LLM_MODEL_PATH` | Path to GGUF model (for llama.cpp) | - |
| `ONNX_MODEL_PATH` | Path to ONNX model | auto-detect |
| `SEMGREP_BACKEND` | Storage: auto, sqlite, lance | auto |

## Benchmark

| Backend | Speed |
|---------|-------|
| llama.cpp | ~1s |
| ONNX | ~3s |
| Ollama | ~6s |

## License

MIT License - see [LICENSE](LICENSE) for details.
